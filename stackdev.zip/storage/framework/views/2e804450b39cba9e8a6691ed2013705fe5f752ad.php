<?php $__env->startSection('container'); ?>

<h1>demo</h1>

<?php echo e($nom); ?> lllllllllllll

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contain'); ?>
<h1>
url shortner................
<form action="" method="POST">
<?php echo e(csrf_field()); ?>

<input type="text" name="url" placeholder="original url">
<input type="submit" name="shortn url">
</form>
</h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>