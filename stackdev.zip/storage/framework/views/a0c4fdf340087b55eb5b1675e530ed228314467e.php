<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="/css/bootstrap.css">

<script src="/js/bootstrap.min.js"></script>
</head>
<body>
   <nav class="navbar navbar-default navbar-static-top">
   <div class="container">
   <div class="navbar-header">
   <a class="navbar-brand" href="">gobicodeur</a>
   </div>
   </div>
   
   </nav> 
 
<div class="container">
                <div class='row'>
                <div class='col-md-12'>
                <h1>Systeme d'administration</h1>
                </div>
                </div>


                <div class='row'>
                <div class='table table-responsive'>
                <table class='table table-bordered' id="table">
                <tr>
                <th width='150px'>No</th>
                <th>title</th>
                <th>body</th>
                <th>created at</th>
                <th class='text-center' width='150px'>
                <a href="#" class="create-modal btn btn-success btn-sm"> 
                <i class="glyphicon glyphicon-plus"></i>
                </a>
                </th>
                </tr>
                <?php echo e(csrf_field()); ?>

                <php $no=1;?>
                <?php $__currentLoopData = $poste; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="poste<?php echo e($value->id); ?>">
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($value->title); ?></td>
                <td><?php echo e($value->body); ?></td>
                <td><?php echo e($value->created_at); ?></td>
                <td>
                <a href="#" class="show-modal btn btn-info btn-sm" data-id="<?php echo e($value->id); ?>" data-title="<?php echo e($value->title); ?>" data-body="<?php echo e($value->body); ?>"> 
                <i class="fa fa-eye"></i>
                </a>
                <a href="#" class="edit-modal btn btn-warning btn-sm" data-id="<?php echo e($value->id); ?>" data-title="<?php echo e($value->title); ?>" data-body="<?php echo e($value->body); ?>"> 
                <i class="glyphicon glyphicon-pencil"></i>
                </a> 
                <a href="#" class="delete-modal btn btn-danger btn-sm" data-id="<?php echo e($value->id); ?>" data-title="<?php echo e($value->title); ?>" data-body="<?php echo e($value->body); ?>"> 
                <i class="glyphicon glyphicon-trash"></i>
                </a>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                </div>
                </div>

    <div class="modal fade" id="create" role="dialog">
    <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title"> </h4>
    </div>
    <div class="modal-body">
     <form action="" class="form-horizontal" role="form">
                <div class="form-group row add">
                <label for="title" class="control-label col-sm-2">title:</label>
                
                <div class="col-sm-10">
                <input type="text" class="form-control" id="title" name="title" placeholder="entrer title">
                <p class="error text-center alert alert-danger hideen"></p>
                </div>
                </div>
                <div class="form-group">
                <label for="body" class="control-label col-sm-2">body:</label>
                
                <div class="col-sm-10">
                <input type="text" class="form-control" id="body" name="body" placeholder="entrer body">
                <p class="error text-center alert alert-danger hideen"></p>
                </div>
                </div>

     </form>
    </div>
     <div class="modal-footer">
                <button type="submit" id="add" class="btn btn-warning">
                <span class="glyphicon glyphicon-plus"></span>save post
                </button>

                <button type="button"  class="btn btn-warning" data-dismiss="modal">
                <span class="glyphicon glyphicon-remove"></span>close
                </button>
     </div>
    </div>
    </div>
</div>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script type="text/javascript">
$(document).on('click','.create-modal',function(){

    $('#create').modal('show');
    $('.form-horizontal').show();
    $('.modal-title').text('Add post');
});
$("#add").click(function(){
    $.ajax({
      type:'post',
      url :'addPost',
      data:{
          '_toktn':$('input[name=_token]').value(),
          'title':$('input[name=title]').value(),
          'body':$('input[name=body]').value(),
      },
      success: function(data){
          if((data.errors)){
              $('.error').removeClass('hidden');
              $('.error').text(data.errors.title);
              $('.error').text(data.errors.body);
          }else{
            $('.error').remove();
            $('#table').append("<tr class='post " + data.id + " '>"+
            
            
                "<td>"+ data.id +"</td>"+
                "<td>"+ data.title +"</td>"+
                "<td>"+ data.body +"</td>"+
                "<td>"+ data.created_at +"</td>"+
                "<td>"
                <a href="#" class="show-modal btn btn-info btn-sm" data-id="<?php echo e($value->id); ?>" data-title="<?php echo e($value->title); ?>" data-body="<?php echo e($value->body); ?>"> 
                <i class="fa fa-eye"></i>
                </a>
                <a href="#" class="edit-modal btn btn-warning btn-sm" data-id="<?php echo e($value->id); ?>" data-title="<?php echo e($value->title); ?>" data-body="<?php echo e($value->body); ?>"> 
                <i class="glyphicon glyphicon-pencil"></i>
                </a> 
                <a href="#" class="delete-modal btn btn-danger btn-sm" data-id="<?php echo e($value->id); ?>" data-title="<?php echo e($value->title); ?>" data-body="<?php echo e($value->body); ?>"> 
                <i class="glyphicon glyphicon-trash"></i>
                </a>
                </td>
                </tr>
            
            
            
            
            
            
            
            
            
            
            
            
            
            )
          }
      }
    });
});
</script>
    
</body>
</html>