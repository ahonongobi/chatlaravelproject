<h5>Messagerie Instantanée</h5>
<table id="tableau" class="table">
 <tbody>
                       <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr class="table-row">
                            
                            <td class="table-text">
                            	
                                
                                <div class="user_img"><img src="/uploads/avatars/<?php echo e($topic->user->avatar); ?>" width="48" height="48" alt="User"><br><small><?php echo e($topic->user->name); ?></small></div> <br>
											   <div id="loadmessages" class="notification_desc">
												<p style="background-color: blue;border-radius: 5px; display: inline-block;color: white;"><?php echo e($topic->content); ?> </p>
												
												</div>
                                

                            </td>
                            <td>
                            	 <i style="color: blue;height: 100px;" class="pull-left fa fa-thumbs-up icon-rounded"></i>
                            </td>
                            <td class="march">
                                
                            </td>
                          
                             <td>
                               <i class="fa fa-star-half-o icon-state-warning"></i>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


 