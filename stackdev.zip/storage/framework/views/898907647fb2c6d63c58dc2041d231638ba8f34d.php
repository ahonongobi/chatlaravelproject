<DOTYPE html>
<html>
<head>
<style>
body{
    
}
</style>

<meta charset="utf-8">
<link rel="stylesheet" href="">
<title>Affichages Complete des informations</title>
</head>
<body>
    <table border ="1">
    <tr>
    <td>Id</td>
    <td>First Name</td>
    <td>Last Name</td>
    <td>city Name</td>
    <td>Email</td>
    </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($user->id); ?></td>
    <td><?php echo e($user->firstName); ?></td>
    <td><?php echo e($user->lastName); ?></td>
    <td><?php echo e($user->cityName); ?></td>
    <td><?php echo e($user->email); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>