<!DOCTYPE html>
<html>
<head>
	<title>About</title>
</head>
<body>
 <h1>About us</h1>

 <p>
 	<?php 
 	
    echo $nom;
    echo $last_Name;

 	 ?>

 </p>
</body>
<?php echo $__env->yieldContent('container'); ?>
</html>