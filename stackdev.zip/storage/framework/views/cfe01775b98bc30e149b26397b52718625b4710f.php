<html>
<head style="margin-left:50%;"><center>Students managemen Edit</center></head>

<body>
<center>
 <form action="/edit/<?php echo $users[0]->id; ?>" method="POST">

 <table>
 <?php echo e(csrf_field()); ?>

 
 <tr>
 <td>First Name</td>
 <td><input type="text" name="firstName" value="<?php echo $users[0]->firstName; ?>"></td>
 </tr>
 <tr>
 <td>Last Name</td>
 <td><input type="text" name="lastName" value="<?php echo $users[0]->lastName; ?>"></td>
 </tr>
 <tr>
 <td>city Name</td>
 <td> 
 <input type="text" name="cityName" value="<?php echo $users[0]->cityName; ?>">
  </td>
 </tr>
 <tr>
  <td>Email</td>
  <td> <input type="text" name="email" value="<?php echo $users[0]->email; ?>">
   </td>
 </tr>
 <tr>
 <td colspan='2'>
 <input type="submit"  value="Updates Students">
 </td>
 </tr>
 </table>
 

</center>
</form>
</body>
</html>
