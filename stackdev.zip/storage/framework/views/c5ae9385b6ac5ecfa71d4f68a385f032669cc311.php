<DOTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="/css/bootstrap.css">
<script src="/js/jquery.min.css"></script>
<script src="/js/bootstrap.min.js"></script>

<title>Affichages Complete des informations</title>
<button style="float:right;" ><a class="btn btn-primary" href="/insert">Ajouter Un client</a></button>
</head><br><br>
<body>
    
    <table class="table table-hover dashboard-task-infos table-bordered"  border="1">
    <thead>
    <tr>
    <th>Id</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>city Name</th>
    <th>Email</th>
    <th>Modifier</th>
    <th>Suppression</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
    <tr>
    <td><?php echo e($user->id); ?></td>
    <td><?php echo e($user->firstName); ?></td>
    <td><?php echo e($user->lastName); ?></td>
    <td><?php echo e($user->cityName); ?></td>
    <td><?php echo e($user->email); ?></td>
    <td><a class="btn btn-primary" href='edit/<?php echo e($user->id); ?>'>Modifier</a></td>
    <td><a class="btn btn-danger" href='delete/<?php echo e($user->id); ?>'>Supprmer</a></td>
    </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>