<!DOCTYPE html>
<html>
<head>
	<title>About</title>
</head>
<body>
 <h1>About us</h1>
 <p>
  
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><?php echo e($client->name); ?></li>
	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 	

 </p>
 <hr>
 <form action="/client " method="POST">
 @csrf
  <div>
   <input type="text" name="pseudo">
  </div>
   <button type="submit">Ajouter un client</button>
 </form>
</body>
</html>