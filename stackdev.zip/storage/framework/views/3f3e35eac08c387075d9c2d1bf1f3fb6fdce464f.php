<html>
<head style="margin-left:50%;"><center>Students management</center></head>

<body>
<center>
 <form action="/create" method="POST">

 <table>
 <?php echo e(csrf_field()); ?>

 
 <tr>
 <td>First Name</td>
 <td><input type="text" name="firstName"></td>
 </tr>
 <tr>
 <td>Last Name</td>
 <td><input type="text" name="lastName"></td>
 </tr>
 <tr>
 <td>city Name</td>
 <td> <select name="cityName" id="">
 <option value="ctn">cotonou</option>
 <option value="parakou">Parakou</option>
 <option value="abuac">Abomey calavi</option>
 </select>
  </td>
 </tr>
 <tr>
  <td>Email</td>
  <td> <input type="text" name="email">
   </td>
 </tr>
 <tr>
 <td colspan='2'>
 <input type="submit"  value="Add Students">
 </td>
 </tr>
 </table>
 

</center>
</form>
</body>
</html>
