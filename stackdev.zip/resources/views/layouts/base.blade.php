<html>
<title></title>
<body>
    @yield('contain')
</body>
</html>