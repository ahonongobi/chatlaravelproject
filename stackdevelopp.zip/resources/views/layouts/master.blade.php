<!DOCTYPE html>
<html>
<head>
	<title>About</title>
</head>
<body>
 <h1>About us</h1>

 <p>
 	<?php 
 	
    echo $nom;
    echo $last_Name;

 	 ?>

 </p>
</body>
@yield('container')
</html>